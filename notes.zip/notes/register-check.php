<?
require_once("main.php");

$email=$_POST['email'];
$password1=$_POST['password1'];
$password2=$_POST['password2'];
$name=$_POST['name'];
$nickname=$_POST['nickname'];
$time=getCurrentDateTime();

$db=Db::getInstance();
$records=$db->first("SELECT * FROM x_user WHERE email='$email'");

if($records !=null){
  $message="yiu are already register";
  require_once("login-failed.php");
  exit;
}

if(strlen($password1) <3 || strlen($password2) <3){
  $message="password is too short";
  require_once("login-failed.php");
  exit;
}

if($password1 != $password2){
  $message="password no match";
  require_once("login-failed.php");
  exit;
}

$db->insert("INSERT INTO x_user(email,fullname,nickname,password,registerTime,lastVisit)VALUES('$email','$name','$nickname','$password1','$time','$time')");
echo
$message="your successfully register ." . '<a href="login.php">login</a>';
require_once("login-success.php");
exit;
?>