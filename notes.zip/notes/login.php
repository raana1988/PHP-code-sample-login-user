<!doctype html>
<?
require_once("main.php");
if(isset($_SESSION['email'])){
  $message="yiu are already login" . '<a href="home.php">go to home page</a> OR <a href="logout.php">go to logout</a>'."<br>
  Email " . $_SESSION['email']  ;
  require_once("login-success.php");
  exit;
}
?>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="base.css">
  <title>Document</title>
</head>
<body>
<div class="tac">
  <div>
  <img src="images/notes-1.png">
    <form action="login-check.php" method="post">
      <input type="text" placeholder="Email" name="email"><br><br>
      <input type="password" placeholder="Password" name="password"><br><br>
      <button type="submit" class="btn-blue">login</button>
      <br>
      <br>
    </form>
    <br><br>
  <a href="register.php" class="link-gray">Create new account</a>
</div>
</div>
<?

?>
</body>
</html>