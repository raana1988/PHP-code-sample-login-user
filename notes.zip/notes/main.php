<?
session_start();
require_once("common.php");
require_once("config.php");
require_once("db.php");
