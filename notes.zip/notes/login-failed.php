<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="base.css">
  <title>Document</title>
</head>
<body>
<div class="tac">
<img src="images/Fire-Toy-icon-link.png" width="200" height="200">
<br>
<br>
<div><?=$message?></div>
</div>
</body>
</html>