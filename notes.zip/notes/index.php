<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
<?
require_once("common.php");
require_once("config.php");
require_once("db.php");

$db=new Db();
$records=$db->query("SELECT * FROM x_note LEFT OUTER JOIN x_user ON x_note.user_id=x_user.user_id");
dump($records);
?>
</body>
</html>

