<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="base.css">
  <title>Document</title>
</head>
<body>
<div class="tac">
  <div>
    <img src="images/notes-1.png">
    <form action="register-check.php" method="post">
      <input type="text" placeholder="Email" name="email"><br><br>
      <input type="text" placeholder="name" name="name"><br><br>
      <input type="text" placeholder="nick name" name="nickname"><br><br>
      <input type="password" placeholder="Password" name="password1"><br>
      <input type="password" placeholder="confirm password" name="password2"><br><br>
      <br>
      <button type="submit" class="btn-blue">login</button>
      <br>
      <br>
    </form>

  </div>
</div>
<?

?>
</body>
</html>