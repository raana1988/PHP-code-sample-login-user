<?
require_once("main.php");

$email=$_POST['email'];
$password=$_POST['password'];

$db=Db::getInstance();

$records=$db->first("SELECT * FROM x_user WHERE email='$email'");

if($records==null){
  $message="Sorry , Please check Email and Password qqq";
  require_once("login-failed.php");
  exit;
}else
{
  if($password == $records['password']){
    $_SESSION['email']=$email;
    $_SESSION['user_id']=$records['user_id'];
    $message="Congratulation , Your welcome";
    require_once("login-success.php");
    exit;

  }else {
    $message="Sorry , Please Password bbb";
    require_once("login-failed.php");
    exit;
  }
}

?>